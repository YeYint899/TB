# chatgpt-bot-telegram
How to Install: <BR>
npm i <BR>
nano .env (ADD TELEGRAM API AND OPENAI API) <BR>
node index.js
